# Book-Directory-System-Using-React-Native
This is the mobile app (React Native) of a book directory system API i had previously built using Node.js, Express.js, Cloudinary &amp; MongoDB's Mongoose. The book directory system can be used in storing, showing off of your favourite books that have been uploaded online.
